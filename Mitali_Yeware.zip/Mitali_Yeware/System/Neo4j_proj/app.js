var express = require("express");
var path = require("path");
var logger = require("morgan");
var bodyParser = require("body-parser");
var neo4j = require("neo4j-driver");
const { resolveSoa } = require("dns");

var app = express();
const mongoFucntions = require("./mongo");

app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");

app.use(logger("dev"));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, "public")));

var driver = neo4j.driver(
  "bolt://localhost:7687",
  neo4j.auth.basic("neo4j", "asdfghjkl")
);
var session = driver.session();

app.get("/", function (req, res) {
  session
    .run("MATCH(se:Side_Effect) RETURN (se)")
    .then(function (result) {
      var seArr = [];
      result.records.forEach(function (record) {
        seArr.push({
          //   id: record._fields[0].identity.low,
          Name: record._fields[0].properties.Name,
        });
        // console.log(record._fields[0].properties);
      });

      session
        .run("MATCH(m:Medicine) RETURN (m)")
        .then(function (result2) {
          var medArr = [];
          result2.records.forEach(function (record) {
            medArr.push({
              // id: record._fields[0].identity.low,
              Name: record._fields[0].properties.Name,
            });
          });
          res.render("index", {
            side_effects: seArr,
            medicines: medArr,
          });
        })
        .catch(function (err) {
          console.log(err);
        });
    })
    .catch(function (err) {
      console.log(err);
    });
});

app.get("/identifyMedicine", function (req, res) {
  var Name3 = req.query.Name3;
  var Name4 = req.query.Name4;
  var Name5 = req.query.Name5;
  var Name6 = req.query.Name6;
  var result3;
  var patient_Name = req.query.Patient_Name;
  console.log("pname", patient_Name);
  session
    .run(
      "MATCH (se:Side_Effect) - [:ofmedicine] - (m:Medicine) where se.Name = $NameParam3 RETURN m",
      {
        NameParam3: Name3,
      }
    )
    .then(function (resu) {
      var temp1 = [];
      resu.records.forEach(function (record) {
        temp1.push(record._fields[0].properties.Name);
        //console.log("temp1", temp1);
      });
      session
        .run(
          "MATCH (se1:Side_Effect) - [:ofmedicine] - (a:Medicine) where se1.Name = $NameParam4 RETURN a",
          {
            NameParam4: Name4,
          }
        )
        .then(function (resu1) {
          var temp2 = [];
          //   console.log("result", resu1.records);
          resu1.records.forEach(function (record) {
            temp2.push(record._fields[0].properties.Name);
            //console.log("temp2", temp2);
          });

          let result1 = identifyMedicine(temp1, temp2);
          //console.log("result1", result1);

          session
            .run(
              "MATCH (se1:Side_Effect) - [:ofmedicine] - (a:Medicine) where se1.Name = $NameParam5 RETURN a",
              {
                NameParam5: Name5,
              }
            )
            .then(function (resu2) {
              var temp3 = [];
              //   console.log("result", resu1.records);
              resu2.records.forEach(function (record) {
                temp3.push(record._fields[0].properties.Name);
                //console.log("temp3", temp3);
              });

              let result2 = identifyMedicine(result1, temp3);
              //console.log("result2", result2);

              session
                .run(
                  "MATCH (se2:Side_Effect) - [:ofmedicine] - (a:Medicine) where se2.Name = $NameParam6 RETURN a",
                  {
                    NameParam6: Name6,
                  }
                )
                .then(function (resu3) {
                  var temp4 = [];
                  //   console.log("result", resu1.records);
                  resu3.records.forEach(function (record) {
                    temp4.push(record._fields[0].properties.Name);
                    //console.log("temp4", temp4);
                  });

                  result3 = identifyMedicine(result2, temp4);
                  //console.log("result3", result3);
                  console.log("result3", result3);
                  const updateMedicine = mongoFucntions.updateValue(
                    patient_Name,
                    result3
                  );
                  res.render("identifyMedicine", {
                    possible_Medicine: result3,
                  });
                  //console.log("res", res);
                });
            });
        });
    })

    .catch(function (err) {
      console.log("err");
    });
});

app.post("/side_effect/add", function (req, res) {
  var Name = req.body.Name;

  session
    .run("CREATE(se:Side_Effect{Name:$NameParam}) RETURN se.Name", {
      NameParam: Name,
    })
    .then(function (result) {
      res.redirect("/");
      session.close();
    })
    .catch(function (err) {
      console.log(err);
    });
  res.redirect("/");
});

app.post("/medicine/add", function (req, res) {
  var Name2 = req.body.Name2;

  session
    .run("CREATE(m:Medicine{Name:$NameParam2}) RETURN m.Name", {
      NameParam2: Name2,
    })
    .then(function (result) {
      res.redirect("/");
      session.close();
    })
    .catch(function (err) {
      console.log(err);
    });
  res.redirect("/");
});

app.post("/side_effect/medicine/add", function (req, res) {
  var Name = req.body.Name;
  var Name2 = req.body.Name2;

  session
    .run(
      "MATCH(se:Side_Effect{Name:$NameParam}), (m:Medicine{Name:$NameParam2}) MERGE (se)-[o:ofmedicine]-(m) RETURN se.Name,m.Name,o",
      {
        NameParam: Name,
        NameParam2: Name2,
      }
    )
    .then(function (result3) {
      var seArr2 = [];
      var medArr2 = [];
      result3.records.forEach(function (record) {
        seArr2.push({
          id: record._fields[0].identity.low,
          Name: record._fields[0].properties.Name,
        });
        medArr2.push({
          id: record._fields[0].identity.low,
          Name: record._fields[0].properties.Name,
        });
        res.redirect("/");
        session.close();
      });

      res.render("index", {
        side_effects: seArr2,
        medicines: medArr2,
      });
    })
    .catch(function (err) {
      console.log(err);
    });
  res.redirect("/");
});

const identifyMedicine = (arr1, arr2) => {
  let output = [];
  arr1.forEach((e) => {
    let checkMedicine = arr2.includes(e);
    checkMedicine && output.push(e);
  });
  return output;
};

app.listen(3000, function () {
  console.log("Server Started on Port 3000");
});
module.exports = app;
